import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;

public class  viewNoticesController {


}
